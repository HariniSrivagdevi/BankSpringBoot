package com.cg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.entity.Account;
import com.cg.service.AccountService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class Controller {
	
	
	@Autowired AccountService service;
	@GetMapping("/accounts")
	public List<Account> getall() {
	return service.getAllAccounts();
		
	}
	
	
	@PostMapping(value = "/accounts/create",consumes= {"application/json"})
	public String add(@RequestBody Account account) {
		 service.addAccount(account);
		 return"Account added";
	}
	
	@GetMapping(value = "accounts/mobileno/{mobileno}")
	    public List<Account> findbyMobileno(@PathVariable("mobileno") Long mobileno) {
	        return service.findAccount(mobileno);
	 }

	 @DeleteMapping("/accounts/mobileno/{mobileno}")	
	    public String deletebyMobileno(@PathVariable("mobileno") Long mobileno) {
	       service.deleteAccount(mobileno);
	       return "Account deleted";
	 }
	 
	 @DeleteMapping("/accounts/delete")	
	    public String deleteAll() {
	       service.deleteAll();
	       return "All Account deleted";
	 }
	 
	 @GetMapping(value="accounts/withdraw/mobileno/{mobileno}/amount/{amount}")
	    public String withdraw(@PathVariable("mobileno") Long mobileno,@PathVariable("amount") Double amount) {
		 service.withdraw(mobileno, amount);
	      
	       return "Amount has been withdrawn";
	 }
	 
	 @GetMapping(value="accounts/deposite/mobileno/{mobileno}/amount/{amount}")	
	    public String deposit(@PathVariable("mobileno") Long mobileno,@PathVariable("amount") Double amount) {
		 service.Deposit(mobileno, amount);
	      
	       return "Amount has been Deposited";
	 }
	 
	 @GetMapping(value="accounts/transfer/{from}/{to}/{amount}")	
	    public String transfer(@PathVariable("from") Long from,@PathVariable("to") Long to,@PathVariable("amount") Double amount) {
		service.TransferMoney(from, to, amount);
	      
	       return "Amount has been transferred";
	 }
}
